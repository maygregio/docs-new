// Shared Mermaid initialization + zoom/pan enhancement for all product pages.
// Requires:
//   <script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"></script>
//   <script src="https://cdn.jsdelivr.net/npm/svg-pan-zoom@3.6.1/dist/svg-pan-zoom.min.js"></script>
//   <script src="mermaid-init.js"></script>

(async function () {
  mermaid.initialize({
    startOnLoad: false,
    theme: 'dark',
    themeVariables: {
      background: '#1c2230',
      primaryColor: '#1c2230',
      primaryTextColor: '#e6e8ef',
      primaryBorderColor: '#02b0ad',
      lineColor: '#5ec8ff',
      secondaryColor: '#232a39',
      tertiaryColor: '#0f1115'
    },
    flowchart: { useMaxWidth: true, htmlLabels: true, curve: 'basis' },
    sequence: { useMaxWidth: true, wrap: true },
    gantt: { useMaxWidth: true }
  });

  await mermaid.run();

  document.querySelectorAll('.mermaid').forEach(container => {
    const svg = container.querySelector('svg');
    if (!svg) return;

    // Mermaid sets max-width on the SVG which prevents svg-pan-zoom from sizing it properly.
    // Override so the SVG fills the container; pan-zoom will manage the viewport.
    svg.style.maxWidth = '100%';
    svg.style.width = '100%';
    svg.style.height = '500px';
    svg.style.display = 'block';

    let pz;
    try {
      pz = svgPanZoom(svg, {
        zoomEnabled: true,
        controlIconsEnabled: false,
        fit: true,
        center: true,
        minZoom: 0.3,
        maxZoom: 10,
        zoomScaleSensitivity: 0.3,
        mouseWheelZoomEnabled: false, // off by default; toggle via button to avoid scroll conflicts
        preventMouseEventsDefault: false,
        dblClickZoomEnabled: true,
        contain: false
      });
    } catch (err) {
      console.warn('svg-pan-zoom init failed:', err);
      return;
    }

    // Build floating control bar
    const controls = document.createElement('div');
    controls.className = 'mermaid-controls';
    controls.innerHTML = `
      <button type="button" title="Zoom in" data-action="in">+</button>
      <button type="button" title="Zoom out" data-action="out">−</button>
      <button type="button" title="Reset view" data-action="reset">⟲</button>
      <button type="button" title="Toggle mouse-wheel zoom" data-action="wheel" aria-pressed="false">🖱</button>
      <button type="button" title="Open fullscreen" data-action="full">⛶</button>
    `;
    container.appendChild(controls);

    container.classList.add('mermaid-ready');

    controls.addEventListener('click', e => {
      const btn = e.target.closest('button');
      if (!btn) return;
      const action = btn.dataset.action;
      if (action === 'in') pz.zoomIn();
      else if (action === 'out') pz.zoomOut();
      else if (action === 'reset') {
        pz.resetZoom();
        pz.resetPan();
      } else if (action === 'wheel') {
        const enabled = btn.getAttribute('aria-pressed') === 'true';
        if (enabled) {
          pz.disableMouseWheelZoom();
          btn.setAttribute('aria-pressed', 'false');
        } else {
          pz.enableMouseWheelZoom();
          btn.setAttribute('aria-pressed', 'true');
        }
      } else if (action === 'full') {
        toggleFullscreen(container, pz);
      }
    });

    // Keyboard zoom when the container has focus (tabindex set below)
    container.setAttribute('tabindex', '0');
    container.addEventListener('keydown', e => {
      if (e.key === '+' || e.key === '=') { e.preventDefault(); pz.zoomIn(); }
      else if (e.key === '-' || e.key === '_') { e.preventDefault(); pz.zoomOut(); }
      else if (e.key === '0') { e.preventDefault(); pz.resetZoom(); pz.resetPan(); }
    });
  });

  function toggleFullscreen(container, pz) {
    if (!document.fullscreenElement) {
      container.requestFullscreen?.().then(() => {
        // Re-fit after the browser settles the fullscreen layout
        setTimeout(() => { pz.resize(); pz.fit(); pz.center(); }, 100);
      });
    } else {
      document.exitFullscreen?.().then(() => {
        setTimeout(() => { pz.resize(); pz.fit(); pz.center(); }, 100);
      });
    }
  }

  // When user exits fullscreen via ESC, re-fit
  document.addEventListener('fullscreenchange', () => {
    document.querySelectorAll('.mermaid svg').forEach(svg => {
      // svg-pan-zoom stores its instance on the SVG; trigger a resize via custom event handler
      const evt = new Event('mermaid-refit');
      svg.dispatchEvent(evt);
    });
  });
})();
